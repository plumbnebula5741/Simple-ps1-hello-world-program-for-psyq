#include <stdlib.h>
#include <libgte.h>
#include <libgpu.h>
#include <libgs.h>
#include "screen.h" // screen script

GsOT orderingTable[2];
short currentBuffer;



int main() {

	initialize();

	while(1) {
		FntPrint("	PLUMB IS A 	BEGGINER CODER");
		display();
	}
	return 0;
}

void initialize() {
	initScreen();
	initFont();
}

void display() {
	currentBuffer = GsGetActiveBuff();
	FntFlush(-1);
	GsClearOt(0, 0, &orderingTable[currentBuffer]);
	DrawSync(0);
	VSync(0);
	GsSwapDispBuff();
	GsSortClear(0, 0, 255, &orderingTable[currentBuffer]); // R, G, B (from 0 to 255)
	GsDrawOt(&orderingTable[currentBuffer]);
}
