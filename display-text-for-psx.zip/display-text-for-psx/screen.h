#pragma once

#include <libgs.h>
#include <libgpu.h>
#define __ramsize   0x00200000
#define __stacksize 0x00004000


int SCREEN_WIDTH, SCREEN_HEIGHT;


    	SCREEN_WIDTH = 320;
    	SCREEN_HEIGHT = 256;


void initScreen() {
	SetVideoMode(1);
	GsInitGraph(SCREEN_WIDTH, SCREEN_HEIGHT, GsINTER|GsOFSGPU, 1, 0);
	GsDefDispBuff(0, 0, 0, SCREEN_HEIGHT);	
}

void initFont() {
	FntLoad(960, 256);
	SetDumpFnt(FntOpen(5, 20, 320, 240, 0, 512)); //Sets the dumped font for use with FntPrint();
}